const waxConfig = {
  rules: [],
  apiKey: "19c4b4c5b007040de9394bdfac9a08852"
};

module.exports = waxConfig;

// export default waxConfig; 