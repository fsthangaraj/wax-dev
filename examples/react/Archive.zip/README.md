# React Testing Demo

A simple React application for testing npm packages with various UI components.

## Features

- Simple React components (Button, Heading, Link)
- Interactive elements with state management
- Testing setup with React Testing Library and Jest
- Production-ready configuration

## Components

- **Button**: Interactive button with click handlers
- **Heading**: Configurable heading levels (h1, h2, h3, etc.)
- **Link**: External links with proper attributes

## Getting Started

### Installation

```bash
npm install
```

### Development

```bash
npm start
```

Runs the app in development mode. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

### Testing

#### **Unit/Integration Tests:**
```bash
npm test                    # Run Jest tests in watch mode
npm run test:coverage       # Run tests with coverage report
```

#### **End-to-End Tests:**
```bash
# Cypress
npm run cypress:open        # Open Cypress Test Runner
npm run cypress:run         # Run Cypress tests headlessly

# Playwright
npm run playwright:install  # Install Playwright browsers
npm run playwright:test     # Run Playwright tests
npm run playwright:test:ui  # Run Playwright tests with UI

# WebdriverIO
npm run webdriverio:test    # Run WebdriverIO tests

# TestCafe
npm run testcafe:test       # Run TestCafe tests

# Nightwatch
npm run nightwatch:test     # Run Nightwatch tests

# Run all E2E tests
npm run e2e:all            # Run all E2E testing frameworks
```

### Building for Production

```bash
npm run build
```

Builds the app for production to the `build` folder.

## Testing Libraries Included

### **Unit/Integration Testing:**
- **Jest** (`^29.7.0`): Test runner and assertion library
- **React Testing Library** (`^14.1.2`): Component testing utilities
- **@testing-library/jest-dom** (`^6.1.4`): Custom Jest matchers for DOM testing
- **@testing-library/user-event** (`^14.5.1`): User interaction simulation

### **End-to-End Testing:**
- **Cypress** (`^14.5.4`): E2E testing framework with component testing
- **Playwright** (`^1.40.0`): Multi-browser E2E testing
- **WebdriverIO** (`^8.0.0`): WebDriver-based E2E testing
- **TestCafe** (`^3.6.0`): E2E testing framework
- **Nightwatch** (`^3.0.0`): E2E testing framework

## Project Structure

```
react/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── Button.jsx
│   │   ├── Heading.jsx
│   │   └── Link.jsx
│   ├── tests/
│   │   ├── playwright/
│   │   │   └── app.spec.js
│   │   ├── webdriverio/
│   │   │   └── app.spec.js
│   │   ├── testcafe/
│   │   │   └── app.test.js
│   │   └── nightwatch/
│   │       └── app.test.js
│   ├── App.jsx
│   ├── App.test.js
│   ├── index.js
│   ├── index.css
│   └── setupTests.js
├── cypress/
│   ├── e2e/
│   │   └── app.cy.js
│   ├── support/
│   │   ├── e2e.js
│   │   └── commands.js
│   └── fixtures/
├── cypress.config.js
├── playwright.config.js
├── wdio.conf.js
├── nightwatch.conf.js
├── package.json
└── README.md
```

## Adding Your NPM Package

To test your npm package:

1. Install your package: `npm install your-package-name`
2. Import and use it in your components
3. Add tests to verify integration
4. Run tests to ensure compatibility

## Available Scripts

- `npm start` - Start development server
- `npm test` - Run tests in watch mode
- `npm run test:coverage` - Run tests with coverage
- `npm run build` - Build for production
- `npm run eject` - Eject from Create React App (irreversible) 